Pawn 4.01 - Copyright 2011 by Thomas Starke - Freeware

Delete file pawn.cfg to show the welcome message again.

Visit the homepage of Pawn at www.pawn.sitesled.com.

Report bugs to tharmon@arcor.de.